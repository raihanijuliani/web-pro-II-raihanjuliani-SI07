<?php
class matakuliah_Model extends CI_Model {
 public $id;
 public $nama;
 public $kode;
 public $sks;
 public $dosen;
}
?>